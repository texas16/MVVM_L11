//
//  DeleteContactUseCase.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

import Foundation

struct DeleteContactUseCase {
    let repository: ContactRepository
    func execute(contact: Contact) {
        return repository.deleteContact(contact)
    }
}

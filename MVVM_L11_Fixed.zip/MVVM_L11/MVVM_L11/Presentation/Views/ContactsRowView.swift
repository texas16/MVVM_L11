//
//  ContactsRowView.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

import SwiftUI

struct ContactsRowView: View {
    let contacts: Contact
    
    var body: some View {
        HStack {
            Text("\(contacts.initials)")
                .foregroundStyle(.white)
                .frame(width: 48, height: 48)
                .background(Color(.systemGray))
                .clipShape(.circle)
            VStack(alignment: .leading){
                Text("\(contacts.firstName) \(contacts.lastName)")
                Text(contacts.email)
                    .foregroundStyle(.gray)
            }
            Spacer()
        }
        .padding(.horizontal)
    }
}

#Preview {
    ContactsRowView(contacts: .init(id: "1", firstName: "James", lastName: "Lebron", email: "james.lebron@gmail.com"))
}

//
//  EditContactView.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

import SwiftUI

struct EditContactView: View {
    
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var viewModel: ContactsViewModel
    
    @State private var contact: Contact
    @State private var contactDidChange: Bool = false
    @State private var showExitConfirmation: Bool = false
    @State private var showDeleteConfirmation: Bool = false
    
    private let originalContact: Contact
    
    init(contact: Contact) {
        _contact = State(initialValue: contact)
        self.originalContact = contact
    }
    
    // TODO: add Edit UI here!!
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

//#Preview {
//    EditContactView()
//}

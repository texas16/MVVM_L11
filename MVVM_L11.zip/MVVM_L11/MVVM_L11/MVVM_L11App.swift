//
//  MVVM_L11App.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

import SwiftUI

@main
struct MVVM_L11App: App {
    var body: some Scene {
        WindowGroup {
            ContactsView()
        }
    }
}

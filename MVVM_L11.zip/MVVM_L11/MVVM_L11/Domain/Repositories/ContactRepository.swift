//
//  ContactRepository.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

protocol ContactRepository {
    func fetchContacts() -> [Contact]
    func addContact(_ contact: Contact)
    func deleteContact(_ contact: Contact)
    func updateContact(_ contact: Contact)
}

//
//  GetContactUseCase.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

import Foundation

struct GetContactUseCase {
    let repository: ContactRepository
    func execute() -> [Contact] {
        return repository.fetchContacts()
    }
}

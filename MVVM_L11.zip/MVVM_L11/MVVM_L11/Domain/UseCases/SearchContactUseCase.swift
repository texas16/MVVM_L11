//
//  SearchContactUseCase.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

import Foundation

struct SearchContactUseCase {
    func execute(query: String, contacts: [Contact]) -> [Contact] {
        guard !query.isEmpty else { return contacts}
        
        return contacts.filter {
            $0.firstName.localizedCaseInsensitiveContains(query) ||
            $0.lastName.localizedCaseInsensitiveContains(query) ||
            $0.email.localizedCaseInsensitiveContains(query)
        }
    }
}



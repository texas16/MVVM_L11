//
//  Contact.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

import Foundation

struct Contact: Identifiable, Hashable {
    let id : String
    var firstName: String
    var lastName: String
    var email: String
    
    var initials: String {
        let firstNameLetter = firstName.prefix(1)
        let lastNameLetter = lastName.prefix(1)
        
        return String(firstNameLetter + lastNameLetter).uppercased()
    }
}

//
//  ContactsViewModel.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

import Foundation

final class ContactsViewModel: ObservableObject {
    @Published private(vset) var contacts : [Contact] = []
    
    private let getContactUseCase: GetContactUseCase
    private let addContactUseCase: AddContactUseCase
    private let deleteContactUseCase: DeleteContactUseCase
    private let updateContactUseCase: UpdateContactUseCase
    private let searchContactUseCase: SearchContactUseCase
    
    init(repository: ContactRepository = InMemoryContactRepository) {
        self.getContactUseCase = getContactUseCase
        self.addContactUseCase = addContactUseCase
        self.deleteContactUseCase = deleteContactUseCase
        self.updateContactUseCase = updateContactUseCase
        self.searchContactUseCase = searchContactUseCase
        
        fetchContacts()
    }
    
    func fetchContacts() {
        contacts = getContactUseCase.execute()
    }
    
    func addContact(_ contact: Contact) {
        addContactUseCase.execute(contact: contact)
        fetchContacts()
    }
    
    func updateContact(_ contact: Contact) {
        updateContactUseCase.execute(contact: contact)
        fetchContacts()
    }
    
    func deleteContact(_ contact: Contact) {
        deleteContactUseCase.execute(contact: contact)
        fetchContacts()
    }
    
    func searchResult(for query: String) -> [Contact] {
        return searchContactUseCase.execute(query: query, contacts: contacts)
    }
    
}

//
//  AddContactsView.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

import SwiftUI

struct AddContactsView: View {
    
    @Environment(.\dismiss) var dismiss
    @EnvironmentObject var viewModel: ContactsViewModel
    
    @State private var contactData: Contact = .init(id: UUID().uuidString, firstName: "", lastName: "", email: "")
    
    // TODO: lets add AddContactsView here!
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    AddContactsView()
}

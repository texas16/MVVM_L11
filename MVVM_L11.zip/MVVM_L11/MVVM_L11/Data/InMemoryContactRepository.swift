//
//  InMemoryContactRepository.swift
//  MVVM_L11
//
//  Created by ilyas uyanik on 4/6/25.
//

import Foundation

final class InMemoryContactRepository: ContactRepository {
    
    private var contacts: [Contact] = [
        .init(id: "1", firstName: "Alex", lastName: "Kay", email: "alexKay@gmail.com"),
        .init(id: "2", firstName: "Bery", lastName: "Cax", email: "berryCax@gmail.com"),
        .init(id: "3", firstName: "Zack", lastName: "Lal", email: "zackLal@gmail.com")
    ]
    
    func fetchContacts() -> [Contact] {
        return contacts
    }
    
    func addContact(_ contact: Contact){
        contacts.append(contact)
    }
    
    func deleteContact(_ contact: Contact) {
        contacts.removeAll { $0.id == contact.id}
    }
    
    func updateContact(_ contact: Contact) {
        if let index = contacts.firstIndex(where: { $0.id == contact.id }) {
            contacts[index] = contact
        }
    }
}
